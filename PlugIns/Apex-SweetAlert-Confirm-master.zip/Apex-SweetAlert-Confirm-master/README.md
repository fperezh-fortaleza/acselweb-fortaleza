 # Apex-SweetAlert-Confirm

![Screenshot](https://github.com/RonnyWeiss/Apex-SweetAlert-Confirm/blob/master/screenshot.gif?raw=true)

That Dynamic Action Plug-in is intended to enable a security query in APEX. For example, before deleting a lot of data, the end user must first enter a comparison text before the page is submitted.

For working Demo just click on:

https://apex.oracle.com/pls/apex/f?p=103428

If you like my stuff, donate me a coffee

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.me/RonnyW1)