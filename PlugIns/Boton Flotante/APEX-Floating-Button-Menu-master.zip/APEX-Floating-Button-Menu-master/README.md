 # APEX-Floating-Button-Menu

![Screenshot](https://github.com/RonnyWeiss/APEX-Floating-Button-Menu/blob/master/screenshot.gif?raw=true)

This plugin is used to add a floating button menu to the page.

Using the Plug-in is very easy just import the it and add it as dynamic action to your apex page with e.g. "On Page Load" as Trigger. Then use as True-Action the Plug-in. The rest is set as example by default, so just start the appliaction and look into the Navigation Bar.

For working Demo just click on:

https://apex.oracle.com/pls/apex/f?p=103428

Login is: user-demo / 123456@

If you like my stuff, donate me a coffee

[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.me/RonnyW1)